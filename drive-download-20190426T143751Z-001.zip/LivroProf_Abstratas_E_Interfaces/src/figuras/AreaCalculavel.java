package figuras;

public interface AreaCalculavel {
	double calculaArea();
}

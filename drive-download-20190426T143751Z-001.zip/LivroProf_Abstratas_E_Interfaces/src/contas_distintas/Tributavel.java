package contas_distintas;

public interface Tributavel {
	public double calcularTributo();
}

package contas_distintas;

public interface ContaTributavel extends ContaInterf{

}

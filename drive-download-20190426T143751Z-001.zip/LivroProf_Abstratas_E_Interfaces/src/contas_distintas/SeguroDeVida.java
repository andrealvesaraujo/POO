package contas_distintas;

public class SeguroDeVida implements Tributavel{
	
	public double calcularTributo() {
		return 42;
	}

}

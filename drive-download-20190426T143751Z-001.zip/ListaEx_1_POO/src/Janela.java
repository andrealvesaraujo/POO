
public class Janela {
	String cor; String material;
}

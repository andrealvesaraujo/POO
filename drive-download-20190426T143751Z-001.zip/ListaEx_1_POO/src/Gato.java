
public class Gato {
	boolean vivo;
	String cor;
	int idade;
	String nome;
	void miar()
	{
		System.out.println("Gato miando");
	}
}

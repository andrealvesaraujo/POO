
public class Casa {
	String cor; int numero;
	Janela janela;
}

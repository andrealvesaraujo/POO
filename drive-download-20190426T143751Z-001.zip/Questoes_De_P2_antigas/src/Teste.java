import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/*String s = "ABCDEFG";
		System.out.println(s.replaceAll("[A,C,E,G]", ""));
		System.out.println(s.toLowerCase());*/

/*Questao 4 (Aval II.2014_02)
 * public static void main(String args[]){
Map<String,Integer> m = new HashMap<String,Integer>();
m.put("J",5);
m.put("A",15);
m.put("AA", 100);

System.out.println(conta(m));

}	
public static int conta(Map mapa){ 
Iterator i = mapa.values().iterator();
int cont=0;
while(i.hasNext()){
	cont+=(Integer)i.next();
}
return cont;
}*/
public class Teste {
		
	public static void main(String args[]){
	
		
	}
}



public class Assento {
private String cor;
public Assento(String c) {
cor=c;
}
public String getCor() {
return cor;
}
public void setCor(String cor) {
this.cor = cor;
}
}


public class Aluno extends Pessoa {
	private String numeroDeMatricula;
	
	public void setNumeroDeMatricula(String n){
		this.numeroDeMatricula=n;
	}
	public String getNumeroDeMatricula(){
		return  this.numeroDeMatricula;
	}
}

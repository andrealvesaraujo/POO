package selvagens;


public class Cachorro extends Animal {
		public void correr()
		{
			System.out.println("Cachorro " + getNome()+ " correndo");
		}
}

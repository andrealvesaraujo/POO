package selvagens;

public class Tartaruga extends Animal {
	public void correr()
	{
		System.out.println("Tartaruga " + getNome()+ " correndo");
	}
}

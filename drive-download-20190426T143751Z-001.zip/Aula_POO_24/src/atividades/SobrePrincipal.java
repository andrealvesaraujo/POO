package atividades;

import coisa_sobrecarga.Sobrecarga;

public class SobrePrincipal {
	public static void main(String args[]){
		System.out.println(Sobrecarga.getSoma(5,10));
		System.out.println(Sobrecarga.getSoma(5,10,70));
		
	}
			
}

package coisa_sobrecarga;

public class Sobrecarga {
	public static int getSoma(int a, int b){
		return a+b;
	}
	public static int getSoma(int a, int b,int c){
		return a+b+c;
	}
}



 

public class Caneta {
private String cor;
private int quantidade;
public String getCor() {
return cor;
}
public void setCor(String cor) {
this.cor = cor;
}
public int getQuantidade() {
return quantidade;
}
public void setQuantidade(int quantidade) {
this.quantidade = quantidade;
}
}
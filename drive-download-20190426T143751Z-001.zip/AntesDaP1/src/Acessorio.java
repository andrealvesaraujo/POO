public class Acessorio {
private String nome;
public Acessorio(String n) {
nome = n;
}
public String getNome() {
return nome;
}
public void setNome(String nome) {
this.nome = nome;
}
}
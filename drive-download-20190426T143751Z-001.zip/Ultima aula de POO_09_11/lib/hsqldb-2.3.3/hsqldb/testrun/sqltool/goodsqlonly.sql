/*
 * $Id: goodsqlonly.sql 610 2008-12-22 15:54:18Z unsaved $
 *
 * Just runs some successful SQL.
 */

CREATE TABLE t(i INTEGER);


public class Gato extends Animal implements Corredor {
	public void correr(){
		System.out.println("Gato corre");
	}

}


public interface Corredor {
	public abstract void correr();
}


public interface Voador {
	public abstract void voar();
}

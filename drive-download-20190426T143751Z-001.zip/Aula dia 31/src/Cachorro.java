
public class Cachorro extends Animal implements Corredor{
	public void correr(){
		System.out.println("Cachorro corre");
	}

}

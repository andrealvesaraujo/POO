
public class Leao  extends Animal{
	public Leao(String nome){
		super(nome);
	
	}
	public Leao(){
		
	}
	public String toString(){
		return this.getNome() + " � le�o";
	}
}

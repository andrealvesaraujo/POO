package Quest�o2;

public interface Treinamento {
	public void treinar();
}

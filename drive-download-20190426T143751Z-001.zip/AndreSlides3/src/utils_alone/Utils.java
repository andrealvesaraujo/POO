package utils_alone;

public class Utils {
	public static double calculaMedia(double n1,double n2){
		double res;
		res=(n1+n2)/2;
		return res;
	}
	public static double calculaMedia(double n1,double n2,double n3){
		double res;
		res=(n1+n2+n3)/3;
		return res;
	}
	public static double calculaMedia(double n1,double n2,double n3,double n4){
		double res;
		res=(n1+n2+n3+n4)/4;
		return res;
	}
}

package prog_principais;
import utils_alone.Utils;
public class UtilsPrincipal {
	public static void main(String[] args){
		System.out.println(Utils.calculaMedia(10, 15));
		System.out.println(Utils.calculaMedia(10.4, 15.3,87,4));
		System.out.println(Utils.calculaMedia(10.4, 15.3,45,7));
		
	}
}

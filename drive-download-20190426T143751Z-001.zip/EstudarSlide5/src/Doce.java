
public class Doce {
	private String doce;

	public String getDoce() {
		return doce;
	}

	public void setDoce(String doce) {
		this.doce = doce;
	}
	
	
}

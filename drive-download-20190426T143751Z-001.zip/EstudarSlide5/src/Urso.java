
public class Urso extends Animal{
	public Urso(String nome,int idade){
		super(nome,idade);
	}
}

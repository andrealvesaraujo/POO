import java.util.List;
import java.util.ArrayList;
public class Principal {
	List L = new ArrayList();
	
	Urso u = new Urso("Joao",10);
	Carro c = new Carro("Motorola");
	Doce d = new Doce(); 
	
	
	
	
}

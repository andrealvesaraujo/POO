
public interface Corredor {
	public void parar();
	public void correr();
}

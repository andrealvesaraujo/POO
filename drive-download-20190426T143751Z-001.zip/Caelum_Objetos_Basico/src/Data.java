
public class Data {
	public int d,m,a;
	
	public String formatada(){
		return d+"/" + m + "/" +a;
	}
}

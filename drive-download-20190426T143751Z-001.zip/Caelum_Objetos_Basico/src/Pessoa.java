
public class Pessoa {
	String nome; int idade;
	public void aniversario()
	{
		this.idade++;
	}
}

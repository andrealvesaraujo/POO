
public class Cliente {
	String nome;
	String cpf;
}


public interface FormasG {
		public abstract double perimetro();
		public abstract double area();
}

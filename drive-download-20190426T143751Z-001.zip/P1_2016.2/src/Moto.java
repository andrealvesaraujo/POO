
public class Moto extends Veiculos{
	
	public Moto(String p,int a,String r){
			super(p,a,r);
		
	}

}

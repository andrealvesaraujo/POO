
public abstract class Figura {
	private String cor;
	
	public Figura(String c){
		this.cor=c;
	}

	
}

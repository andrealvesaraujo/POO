
public class Carro extends Veiculos{
	public Carro(String p,int a,String r){
		super(p,a,r);
	}
}


public interface Cortavel {
	public void cortar();
}

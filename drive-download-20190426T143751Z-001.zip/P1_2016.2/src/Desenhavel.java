
public interface Desenhavel {
	public void desenhar();
}

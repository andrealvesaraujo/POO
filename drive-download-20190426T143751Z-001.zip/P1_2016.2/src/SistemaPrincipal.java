import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
public class SistemaPrincipal {
	public static void main(String args[]){
		Scanner in = new Scanner(System.in);
		String entrada = in.next();
		List roubos = Detrano.getVeiculosRoubados();
		System.out.println(roubos);
		
		Figura[] F = new Figura[100];
		
		
		
	}
}

//Pagina 39 - Ex 1
public class Ex3_13_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			for(int i=150;i<=300;i++){
				System.out.println(i);
			}
	}

}

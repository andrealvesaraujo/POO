//Capitulo 3 - pagina 29 da apostila da Caelum sobre Java
public class BalancoTrimestral {

	public static void main(String[] args) {
		int jan=15000;
		int fev=23000;
		int marc=17000;
		int trime=jan+fev+marc;
		System.out.println(trime);
		System.out.println("Valor da media mensal: " + trime/3);
		
	}

}

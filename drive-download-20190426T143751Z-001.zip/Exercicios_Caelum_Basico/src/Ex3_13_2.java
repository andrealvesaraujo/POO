
public class Ex3_13_2 {
	public static void main(String[] args){
		int soma=0; int i;
		for(i=1;i<1000;i++){
			soma=soma+i;
		}
	}
}

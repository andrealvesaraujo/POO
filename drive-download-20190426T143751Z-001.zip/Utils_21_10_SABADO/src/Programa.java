/*
 * ---------------------------------JAR-------------
 * Vai em export e depois em Java-->JAR File.
 �*� um zip.Se quiser abrir � para transformar em .zip e extrair.
 
 	Depois em outro projeto vai para Properties-->Java Build Path-->Libraries-->Add External Java
	Com isso eu posso conseguir outras classes para utilizar
  
 */
public class Programa {
	public static void main(String args[]){
		System.out.println(Funcoes.media(3, 2));
	}
}
